import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { IssueService } from '../../services/issue.service';

@Component({
  selector: 'app-issue-details',
  templateUrl: './issue-details.component.html',
  styleUrls: ['./issue-details.component.scss']
})
export class IssueDetailsComponent implements OnInit, OnDestroy {

  subscription: Subscription;
  issueDetails: any;

  constructor(private route: ActivatedRoute, private issueService: IssueService) { }

  ngOnInit() {
    this.subscription = this.route.params.subscribe(params => {
      this.issueService.getIssueDetails(params?.id).subscribe((response) => {
        this.issueDetails = response;
        debugger;
      });
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
