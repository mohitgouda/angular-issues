import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IssueService } from '../../services/issue.service';

@Component({
  selector: 'app-issues-table',
  templateUrl: './issues-table.component.html',
  styleUrls: ['./issues-table.component.scss']
})
export class IssuesTableComponent implements OnInit {

  issuesList = [];
  filteredIssuesList = [];
  defaultPageSize = 10;
  defaultPageNumber = 10;
  pageNumber = 1;
  totalPages = 2;
  currentPage = 1;
  paginationObjects = [];
  openIssues = 0;
  searchText = '';
  constructor(private router: Router, private issueService: IssueService) { }

  ngOnInit() {
    this.issueService.getAngularIssuesDescription().subscribe((response) => {
      this.openIssues = response['open_issues'];
      this.totalPages = Math.ceil(this.openIssues / 10);
      this.paginationObjects.push({
        number: 1, isActive: true
      });
      for (let i = 2; i <= this.totalPages; i++) {
        this.paginationObjects.push({
          number: i, isActive: false
        });
      }
    });
    this.issueService.getIssues(this.defaultPageSize, this.defaultPageNumber).subscribe((response) => {
      this.issuesList = response['items'];
      this.onSearch();
    });
  }
  showInfo(issue) {
    this.router.navigate(['/details', issue?.number]);
  }
  showPage(pageNumber) {
    if (pageNumber > 0 && pageNumber <= this.totalPages) {
      this.currentPage = pageNumber;
      const newObject = [];
      for (let i = 1; i <= this.paginationObjects.length; i++) {
        newObject.push({ number: i, isActive: false });
      }
      this.paginationObjects = newObject;
      this.paginationObjects[pageNumber - 1].isActive = true;
      this.issueService.getIssues(this.defaultPageSize, pageNumber).subscribe((response) => {
        this.issuesList = response['items'];
        this.onSearch();
      });
    }
  }

  onSearch() {
    debugger;
    console.log(this.searchText);
    this.filteredIssuesList = this.issuesList.filter((data) => {
      return data?.title?.includes(this.searchText);
    });
  }
}
