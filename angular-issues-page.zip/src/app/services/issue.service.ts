import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class IssueService {

  constructor(private httpClient: HttpClient) { }

  getAngularIssuesDescription() {
    const apiUrl = 'https://api.github.com/repos/angular/angular';
    return this.httpClient.get(apiUrl).pipe(
      retry(1),
      catchError(this.handleError));
  }

  getIssues(pageSize, pageNumber) {
    const apiUrl = 'https://api.github.com/search/issues?q=repo:angular/angular/node+type:issue+state:open&per_page='
      + pageSize + '&page=' + pageNumber;
    return this.httpClient.get(apiUrl).pipe(
      retry(1),
      catchError(this.handleError));
  }

  getIssueDetails(issueId) {
    const apiUrl = 'https://api.github.com/repos/angular/angular/issues/' + issueId;
    return this.httpClient.get(apiUrl).pipe(
      retry(1),
      catchError(this.handleError));
  }

  handleError = (error: any) => {
    debugger;
    let errorMessage = '';
    if (error?.error?.message !== '') {
      errorMessage = `Error: ${error?.error?.message}`;
    }
    alert(errorMessage);
    return errorMessage;
  }
}
